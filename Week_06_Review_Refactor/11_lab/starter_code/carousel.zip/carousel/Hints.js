var array = [1, 2, "hi", "bop"];


//everything that runs should be in here
$(document).ready(function () {
	//...
});


//click listener for element with class called "class"
$(".class").click(function() {
	everything 
});


//what does this do?
$("#elementId").attr("src","hi.jpg");
 

 //what about this?
 $("tag-name").val();


//If you are confused by what any of the above things do, put it in console!  
//Trying typing: $(".back") in console. 